const API_URL = import.meta?.env?.VITE_API_URL || "http://localhost:3000";

function authHeader() {
  const t =
    typeof localStorage !== "undefined"
      ? localStorage.getItem("access_token")
      : null;
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function handle(res) {
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const ct = res.headers.get("content-type") || "";
  return ct.includes("json") ? res.json() : res.text();
}

export const api = {
  setToken: (getter) => {
    api._getToken = getter;
  },
  async get(url) {
    const res = await fetch(API_URL + url, {
      headers: { "Content-Type": "application/json", ...authHeader() },
    });
    return handle(res);
  },
  async post(url, body) {
    const res = await fetch(API_URL + url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify(body || {}),
    });
    return handle(res);
  },
  async put(url, body) {
    const res = await fetch(API_URL + url, {
      method: "PUT",
      headers: { "Content-Type": "application/json", ...authHeader() },
      body: JSON.stringify(body || {}),
    });
    return handle(res);
  },
  async del(url) {
    const res = await fetch(API_URL + url, {
      method: "DELETE",
      headers: { "Content-Type": "application/json", ...authHeader() },
    });
    return handle(res);
  },
};
