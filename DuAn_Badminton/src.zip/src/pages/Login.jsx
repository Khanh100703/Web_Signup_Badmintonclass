import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth.js";

export default function Login() {
  const nav = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    const ok = await login(email, password);
    if (ok) nav("/");
    else setErr("Sai email/mật khẩu");
  }

  return (
    <div className="max-w-md mx-auto px-4 py-14">
      <h1 className="text-3xl font-bold mb-6">Đăng nhập</h1>
      <form onSubmit={onSubmit} className="grid gap-4">
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="border rounded-xl px-4 py-3"
          placeholder="Email"
        />
        <input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border rounded-xl px-4 py-3"
          placeholder="Mật khẩu"
          type="password"
        />
        {err && <div className="text-red-600 text-sm">{err}</div>}
        <button className="px-4 py-3 rounded-2xl bg-black text-white">
          Đăng nhập
        </button>
      </form>
    </div>
  );
}
