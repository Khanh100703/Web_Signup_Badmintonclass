import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-blue-50 to-white border-b">
        <div className="max-w-6xl mx-auto px-4 py-16 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl font-extrabold text-emerald-600 p-4 bg-emerald-50 rounded-2xl">
              Tailwind ĐÃ hoạt động 🎉
            </h1>

            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
              Lớp học cầu lông cơ bản – nâng cao tại TP.HCM
            </h1>
            <p className="mt-4 text-gray-600">
              Giáo trình theo chuẩn BWF, HLV chuyên nghiệp, giờ học linh hoạt.
              Đăng ký ngay để nhận buổi học thử miễn phí.
            </p>
            <div className="mt-6 flex gap-4">
              <Link
                to="/classes"
                className="px-5 py-3 rounded-2xl bg-black text-white"
              >
                Xem khóa học
              </Link>
              <a href="#pricing" className="px-5 py-3 rounded-2xl border">
                Học phí
              </a>
            </div>
          </div>
          <div className="aspect-video rounded-2xl shadow bg-gray-100" />
        </div>
      </section>

      {/* Khóa học nổi bật */}
      <section className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-bold mb-6">Các khóa học</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {["Người lớn cơ bản", "Kèm riêng", "Trẻ em"].map((t, i) => (
            <Link
              key={i}
              to="/classes"
              className="rounded-2xl border p-5 hover:shadow"
            >
              <div className="h-36 rounded-xl bg-gray-100 mb-3" />
              <div className="font-semibold">{t}</div>
              <div className="text-sm text-gray-600 mt-1">
                Thứ 2-4-6 / 3-5-7 · 18:00–20:00
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Lịch học */}
      <section className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-bold mb-4">Lịch học</h2>
        <div className="overflow-x-auto rounded-2xl border">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left p-3">Lớp</th>
                <th className="text-left p-3">Thời gian</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-t">
                <td className="p-3">Buổi tối (T2-4-6 & 3-5-7)</td>
                <td className="p-3">Ca 1: 18h–20h · Ca 2: 20h–22h</td>
              </tr>
              <tr className="border-t">
                <td className="p-3">Cuối tuần (T7 & CN)</td>
                <td className="p-3">Sáng 9h–11h · Chiều 15h–17h</td>
              </tr>
              <tr className="border-t">
                <td className="p-3">Kèm riêng</td>
                <td className="p-3">Linh hoạt</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Học phí */}
      <section id="pricing" className="max-w-6xl mx-auto px-4 py-14">
        <h2 className="text-2xl font-bold mb-4">Học phí</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { t: "3 buổi/tuần", p: "950.000đ/tháng/12 buổi" },
            { t: "2 buổi/tuần", p: "750.000đ/tháng/8 buổi" },
            { t: "Kèm riêng", p: "300.000–500.000đ/giờ" },
          ].map((x, i) => (
            <div key={i} className="rounded-2xl border p-6">
              <div className="text-lg font-semibold">{x.t}</div>
              <div className="text-2xl font-bold mt-2">{x.p}</div>
              <button className="mt-4 px-4 py-2 rounded-xl border">
                Đăng ký
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
