import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api.js";

export default function ClassDetail() {
  const { id } = useParams();
  const [clazz, setClazz] = useState(null);
  const [sessions, setSessions] = useState([]);

  useEffect(() => {
    (async () => {
      const res1 = await api.get(`/api/classes/${id}`);
      setClazz(res1.data);
      const res2 = await api.get(`/api/sessions/class/${id}`);
      setSessions(res2 || []);
    })();
  }, [id]);

  async function enroll(session_id) {
    const out = await api.post(`/api/enrollments`, { session_id });
    alert(
      out?.message ||
        (out?.waitlisted ? "Đã đưa vào danh sách chờ" : "Đăng ký thành công")
    );
  }

  if (!clazz)
    return <div className="max-w-6xl mx-auto px-4 py-10">Đang tải…</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold">{clazz.title}</h1>
      <p className="text-gray-600 mt-2">{clazz.description}</p>
      <div className="mt-6">
        <h2 className="text-xl font-semibold mb-3">Các buổi học</h2>
        <div className="overflow-x-auto rounded-2xl border">
          <table className="w-full text-sm">
            <thead className="bg-gray-50">
              <tr>
                <th className="p-3 text-left">Bắt đầu</th>
                <th className="p-3 text-left">Kết thúc</th>
                <th className="p-3 text-left">Tác vụ</th>
              </tr>
            </thead>
            <tbody>
              {sessions.map((s) => (
                <tr key={s.id} className="border-t">
                  <td className="p-3">
                    {new Date(s.start_time).toLocaleString()}
                  </td>
                  <td className="p-3">
                    {new Date(s.end_time).toLocaleString()}
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => enroll(s.id)}
                      className="px-3 py-2 rounded-xl border hover:shadow"
                    >
                      Đăng ký
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
