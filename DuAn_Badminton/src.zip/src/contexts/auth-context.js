import { createContext } from "react";

export const AuthCtx = createContext(null);
