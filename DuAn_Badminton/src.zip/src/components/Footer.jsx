export default function Footer() {
  return (
    <footer className="border-t bg-gray-50 mt-16">
      <div className="max-w-6xl mx-auto px-4 py-10 text-sm grid sm:grid-cols-2 gap-8">
        <div>
          <div className="text-lg font-semibold mb-2">Trung tâm Cầu lông</div>
          <p>Hotline/Zalo: 0909 982 629</p>
          <p>Email: contact@example.com</p>
          <p>Giờ làm việc: Thứ 2–CN, 8h–22h</p>
        </div>
        <div>
          <div className="text-lg font-semibold mb-2">Địa chỉ</div>
          <p>Nhà thi đấu TDTT Phú Thọ – 221 Lý Thường Kiệt, Q.11</p>
          <p>Cơ sở Tân Phú – 96/7 Đường Hòa Bình</p>
        </div>
      </div>
      <div className="text-center text-xs py-4 bg-white">
        © {new Date().getFullYear()} Học Cầu Lông
      </div>
    </footer>
  );
}
